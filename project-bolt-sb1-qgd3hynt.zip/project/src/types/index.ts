export interface CaseImage {
  id: string;
  base64Data: string;
  fileName: string;
}

export interface ImageStore {
  images: CaseImage[];
  currentIndex: number;
  addImage: (file: File) => void;
  removeImage: (id: string) => void;
  setCurrentIndex: (index: number) => void;
  nextImage: () => void;
  getCurrentImage: () => CaseImage | null;
}