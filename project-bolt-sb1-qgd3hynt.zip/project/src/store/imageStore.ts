import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ImageStore } from '../types';

export const useImageStore = create<ImageStore>()(
  persist(
    (set, get) => ({
      images: [],
      currentIndex: 0,

      addImage: (file: File) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64String = reader.result as string;
          set((state) => ({
            images: [...state.images, {
              id: crypto.randomUUID(),
              base64Data: base64String,
              fileName: file.name
            }],
          }));
        };
        reader.readAsDataURL(file);
      },

      removeImage: (id: string) => {
        set((state) => ({
          images: state.images.filter((img) => img.id !== id),
        }));
      },

      setCurrentIndex: (index: number) => {
        set({ currentIndex: index });
      },

      nextImage: () => {
        set((state) => ({
          currentIndex: (state.currentIndex + 1) % state.images.length,
        }));
      },

      getCurrentImage: () => {
        const { images, currentIndex } = get();
        return images[currentIndex] || null;
      },
    }),
    {
      name: 'case-images-storage',
      version: 1,
    }
  )
);