import React, { useState, useEffect, useRef } from 'react';
import { useImageStore } from '../store/imageStore';
import { ChevronDown } from 'lucide-react';

interface CaseOpeningProps {
  onRevealComplete?: () => void;
}

export const CaseOpening: React.FC<CaseOpeningProps> = ({ onRevealComplete }) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const images = useImageStore((state) => state.images);
  const currentIndex = useImageStore((state) => state.currentIndex);
  const setCurrentIndex = useImageStore((state) => state.setCurrentIndex);
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!isAnimating || !containerRef.current) return;

    const duration = 7000; // 7 seconds total animation
    const startTime = performance.now();
    const itemWidth = containerRef.current.scrollWidth / images.length;
    const targetIndex = currentIndex;
    const targetScroll = itemWidth * targetIndex;
    
    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      if (elapsed >= duration) {
        setIsAnimating(false);
        if (containerRef.current) {
          containerRef.current.scrollLeft = targetScroll;
        }
        onRevealComplete?.();
        return;
      }

      const progress = elapsed / duration;
      // Easing function for smooth slowdown
      const eased = 1 - Math.pow(1 - progress, 4);
      
      if (containerRef.current) {
        const totalScroll = containerRef.current.scrollWidth - containerRef.current.clientWidth;
        const scrollAmount = eased * totalScroll;
        containerRef.current.scrollLeft = scrollAmount % totalScroll;
      }

      requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);
  }, [isAnimating, onRevealComplete, images.length, currentIndex, setCurrentIndex]);

  const handleStart = () => {
    if (isAnimating || images.length === 0) return;
    // Set a random target index for the reveal
    const randomIndex = Math.floor(Math.random() * images.length);
    setCurrentIndex(randomIndex);
    setIsAnimating(true);
  };

  return (
    <div className="relative w-full aspect-video bg-gradient-to-br from-slate-900 to-slate-800 rounded-lg overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
        <ChevronDown className="text-yellow-500 animate-bounce" size={32} />
      </div>
      <div 
        ref={containerRef}
        className="absolute inset-0 flex overflow-x-hidden"
        style={{ scrollBehavior: 'auto' }}
      >
        {images.map((image, index) => (
          <div
            key={`${image.id}-${index}`}
            className="flex-shrink-0 w-full h-full"
          >
            <img
              src={image.base64Data}
              alt={`Case item ${index + 1}`}
              className="w-full h-full object-contain"
            />
          </div>
        ))}
      </div>
      
      {!isAnimating && (
        <button
          onClick={handleStart}
          disabled={images.length === 0}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-yellow-500 text-black font-semibold rounded-full
            hover:bg-yellow-400 transition-colors duration-200 shadow-lg hover:shadow-xl
            disabled:bg-gray-500 disabled:cursor-not-allowed"
        >
          Spin Again
        </button>
      )}
    </div>
  );
};