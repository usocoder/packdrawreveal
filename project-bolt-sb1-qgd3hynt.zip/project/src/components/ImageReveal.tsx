import React from 'react';
import { useImageStore } from '../store/imageStore';

interface ImageRevealProps {
  isRevealed: boolean;
}

export const ImageReveal: React.FC<ImageRevealProps> = ({ isRevealed }) => {
  const currentImage = useImageStore((state) => state.getCurrentImage());

  if (!currentImage) {
    return (
      <div className="relative w-full aspect-video rounded-lg overflow-hidden bg-slate-800 flex items-center justify-center">
        <p className="text-slate-400">No images uploaded yet</p>
      </div>
    );
  }

  return (
    <div className="relative w-full aspect-video rounded-lg overflow-hidden bg-slate-900">
      <div className="absolute inset-0 flex items-center justify-center">
        <img
          src={currentImage.base64Data}
          alt="Revealed item"
          className={`max-h-full max-w-full object-contain transition-all duration-1000
            ${isRevealed ? 'opacity-100 scale-100' : 'opacity-0 scale-110'}`}
          draggable={false}
        />
      </div>
    </div>
  );
};