import React from 'react';
import { X } from 'lucide-react';
import { useImageStore } from '../store/imageStore';

export const ImageGallery: React.FC = () => {
  const images = useImageStore((state) => state.images);
  const removeImage = useImageStore((state) => state.removeImage);

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-8">
      {images.map((image) => (
        <div key={image.id} className="relative group aspect-video">
          <img
            src={image.base64Data}
            alt="Case item"
            className="w-full h-full object-contain bg-slate-800 rounded-lg"
          />
          <button
            onClick={() => removeImage(image.id)}
            className="absolute top-2 right-2 p-1 bg-red-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <X size={16} className="text-white" />
          </button>
        </div>
      ))}
    </div>
  );
};