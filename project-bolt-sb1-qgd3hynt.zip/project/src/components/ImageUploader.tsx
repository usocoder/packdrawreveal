import React, { useCallback } from 'react';
import { Upload } from 'lucide-react';
import { useImageStore } from '../store/imageStore';

export const ImageUploader: React.FC = () => {
  const addImage = useImageStore((state) => state.addImage);
  const images = useImageStore((state) => state.images);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach((file) => {
      if (file.type.startsWith('image/')) {
        addImage(file);
      }
    });
    
    // Reset input
    e.target.value = '';
  }, [addImage]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center w-full">
        <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer border-slate-600 hover:border-yellow-500 bg-slate-800/50">
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <Upload className="w-8 h-8 mb-3 text-yellow-500" />
            <p className="mb-2 text-sm text-slate-400">
              <span className="font-semibold">Click to upload</span> or drag and drop
            </p>
            <p className="text-xs text-slate-500">Images only</p>
          </div>
          <input
            type="file"
            className="hidden"
            accept="image/*"
            multiple
            onChange={handleFileChange}
          />
        </label>
      </div>
      <div className="text-sm text-slate-400">
        {images.length} images uploaded
      </div>
    </div>
  );
};