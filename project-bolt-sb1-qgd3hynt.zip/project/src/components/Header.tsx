import React from 'react';
import { GalleryHorizontal } from 'lucide-react';

export const Header: React.FC = () => (
  <header className="py-6 px-4 border-b border-slate-800">
    <div className="max-w-7xl mx-auto flex flex-col items-center justify-between space-y-4">
      <div className="flex items-center space-x-2">
        <GalleryHorizontal className="text-yellow-500" size={32} />
        <h1 className="text-2xl font-bold">Relowd.nz</h1>
      </div>
      <h2 className="text-xl font-semibold text-yellow-500">WGTV Packdraw Revealer</h2>
    </div>
  </header>
);