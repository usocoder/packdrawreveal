import React, { forwardRef } from 'react';
import { CaseImage } from '../../types';

interface CaseContainerProps {
  images: CaseImage[];
}

export const CaseContainer = forwardRef<HTMLDivElement, CaseContainerProps>(
  ({ images }, ref) => (
    <div 
      ref={ref}
      className="absolute inset-0 flex overflow-x-hidden"
      style={{ scrollBehavior: 'auto' }}
    >
      {/* Duplicate the images for smooth infinite scroll effect */}
      {[...images, ...images, ...images].map((image, index) => (
        <div
          key={`${image.id}-${index}`}
          className="flex-shrink-0 w-full h-full flex items-center justify-center bg-slate-900"
          style={{ minWidth: '100%' }}
        >
          <img
            src={image.base64Data}
            alt={`Case item ${index + 1}`}
            className="max-h-full max-w-full object-contain"
            draggable={false}
          />
        </div>
      ))}
    </div>
  )
);