import React from 'react';

interface SpinButtonProps {
  isAnimating: boolean;
  onSpin: () => void;
}

export const SpinButton: React.FC<SpinButtonProps> = ({ isAnimating, onSpin }) => {
  if (isAnimating) return null;

  return (
    <button
      onClick={onSpin}
      className="absolute bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-yellow-500 text-black font-semibold rounded-full
        hover:bg-yellow-400 transition-colors duration-200 shadow-lg hover:shadow-xl
        disabled:bg-gray-500 disabled:cursor-not-allowed"
    >
      Spin Again
    </button>
  );
};