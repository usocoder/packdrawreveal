import { useState, useEffect, useRef } from 'react';
import { useImageStore } from '../../store/imageStore';

export const useCaseAnimation = (onRevealComplete?: () => void) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const images = useImageStore((state) => state.images);
  const setCurrentIndex = useImageStore((state) => state.setCurrentIndex);

  useEffect(() => {
    if (!isAnimating || !containerRef.current || selectedIndex === null) return;

    const duration = 7000;
    const startTime = performance.now();
    const container = containerRef.current;
    const itemWidth = container.clientWidth;
    const totalWidth = itemWidth * images.length;
    const targetScroll = itemWidth * selectedIndex;
    let frameId: number;

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      
      if (elapsed >= duration) {
        setIsAnimating(false);
        container.scrollLeft = targetScroll;
        setCurrentIndex(selectedIndex);
        onRevealComplete?.();
        return;
      }

      const progress = elapsed / duration;
      
      // Multi-phase easing for more dramatic effect
      let eased;
      if (progress < 0.5) {
        // Fast start with linear movement
        eased = progress * 2;
      } else if (progress < 0.8) {
        // Begin slowing down
        eased = 1 - Math.pow(1 - ((progress - 0.5) * 3.33), 2);
      } else {
        // Final precise positioning
        eased = 1 - Math.pow(1 - ((progress - 0.8) * 5), 3);
      }
      
      // Calculate total scroll with multiple rotations
      const rotations = Math.floor(images.length * 3); // Spin through items three times
      const baseScroll = rotations * totalWidth;
      const finalAdjustment = targetScroll;
      const totalScroll = baseScroll + finalAdjustment;
      
      container.scrollLeft = eased * totalScroll;
      frameId = requestAnimationFrame(animate);
    };

    frameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameId);
  }, [isAnimating, images.length, selectedIndex, setCurrentIndex, onRevealComplete]);

  const handleStart = () => {
    if (isAnimating || images.length === 0) return;
    const newIndex = Math.floor(Math.random() * images.length);
    setSelectedIndex(newIndex);
    setIsAnimating(true);
  };

  return {
    isAnimating,
    containerRef,
    handleStart
  };
};