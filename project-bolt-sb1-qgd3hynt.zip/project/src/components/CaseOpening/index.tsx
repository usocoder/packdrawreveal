import React from 'react';
import { CaseContainer } from './CaseContainer';
import { CasePointer } from './CasePointer';
import { SpinButton } from './SpinButton';
import { useImageStore } from '../../store/imageStore';
import { useCaseAnimation } from './useCaseAnimation';

interface CaseOpeningProps {
  onRevealComplete?: () => void;
}

export const CaseOpening: React.FC<CaseOpeningProps> = ({ onRevealComplete }) => {
  const { isAnimating, containerRef, handleStart } = useCaseAnimation(onRevealComplete);
  const images = useImageStore((state) => state.images);

  return (
    <div className="relative w-full aspect-video bg-gradient-to-br from-slate-900 to-slate-800 rounded-lg overflow-hidden">
      <CasePointer />
      <CaseContainer ref={containerRef} images={images} />
      <SpinButton isAnimating={isAnimating} onSpin={handleStart} />
    </div>
  );
};