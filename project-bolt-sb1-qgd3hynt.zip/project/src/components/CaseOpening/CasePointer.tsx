import React from 'react';
import { ChevronDown } from 'lucide-react';

export const CasePointer: React.FC = () => (
  <div className="absolute top-0 left-1/2 -translate-x-1/2 z-10">
    <div className="h-1 w-2 bg-yellow-500" />
    <ChevronDown className="text-yellow-500" size={24} />
  </div>
);