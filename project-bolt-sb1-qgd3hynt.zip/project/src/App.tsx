import React, { useState } from 'react';
import { CaseOpening } from './components/CaseOpening';
import { ImageReveal } from './components/ImageReveal';
import { ImageUploader } from './components/ImageUploader';
import { ImageGallery } from './components/ImageGallery';
import { Header } from './components/Header';
import { useImageStore } from './store/imageStore';

function App() {
  const [isRevealed, setIsRevealed] = useState(false);
  const nextImage = useImageStore((state) => state.nextImage);
  const hasImages = useImageStore((state) => state.images.length > 0);

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Header />

      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-bold">Case Opening</h2>
            <p className="text-slate-400">Upload your images and watch the animation reveal them</p>
          </div>

          <ImageUploader />

          {hasImages && (
            <>
              <div className="relative">
                {!isRevealed && (
                  <CaseOpening onRevealComplete={() => setIsRevealed(true)} />
                )}
                <ImageReveal isRevealed={isRevealed} />
              </div>

              {isRevealed && (
                <div className="text-center">
                  <button
                    onClick={() => {
                      setIsRevealed(false);
                      nextImage();
                    }}
                    className="px-6 py-3 bg-yellow-500 text-black font-semibold rounded-full
                      hover:bg-yellow-400 transition-colors duration-200"
                  >
                    Spin Again
                  </button>
                </div>
              )}
            </>
          )}

          <ImageGallery />
        </div>
      </main>
    </div>
  );
}

export default App;